# Formulario de actividades en empresa

Aplicación estática hecha con HTML, JavaScript y JSON.

## Archivos

- `index.html`: formulario completo.
- `claves.json`: listado de claves permitidas generadas a partir del DNI y el NIA.
- `ras.json`: listado de módulos, código de módulo, RA y descripciones.

## Cambio incluido

La aplicación ahora lee correctamente un `ras.json` con este formato:

```json
[
  {
    "codigoModulo": "0485",
    "modulo": "Programación",
    "ra": "RA1",
    "descripcion": "Reconoce la estructura de un programa informático."
  }
]
```

La tabla muestra la columna `Código módulo`.

El JSON descargado por el usuario también incluye `codigoModulo` dentro de cada actividad.

## Funcionamiento

El usuario introduce:

- DNI
- NIA
- Fecha de inicio
- Fecha de fin
- Actividades desarrolladas en la empresa

Al pulsar `Guardar y descargar JSON`, la aplicación:

1. Valida que el DNI tenga 8 números y la letra correcta.
2. Valida que el NIA contenga únicamente números.
3. Calcula una clave de validación usando únicamente la parte numérica del DNI y el NIA.
4. Comprueba que esa clave esté en `claves.json`.
5. Descarga un JSON individual con la respuesta.

Esta versión no usa `localStorage`.

No guarda datos en el navegador.
No acumula respuestas.
No hace seguimiento.

## Operación de validación de claves

La operación usa solo la parte numérica del DNI y el NIA.

```text
D = parte numérica del DNI
N = NIA

sumaDni = suma de los dígitos de D
sumaNia = suma de los dígitos de N

A = sumaDni + sumaNia
B = valor_absoluto(sumaDni - sumaNia)

ponderadoDni = suma de cada dígito de D multiplicado por (posición + 2)^3
ponderadoNia = suma de cada dígito de N multiplicado por (posición + 3)^3

C = valor_absoluto(ponderadoDni - ponderadoNia)

clave =
10000000000000 +
(
  D * 97 +
  N * 31 +
  invertir(D) * 17 +
  invertir(N) * 13 +
  C * 7 +
  A * 1009 +
  B * 917
) % 90000000000000
```

## Ejemplo de claves.json

```json
[
  "10002700108689",
  "10001303330690",
  "10002541366774"
]
```


## Ajuste visual de tabla

La tabla asigna ahora:

- 40% de ancho a `Descripción del RA`.
- 40% de ancho a `Actividad desarrollada en la empresa`.
- Los títulos de las columnas aparecen centrados.


## Ajuste de código de módulo

El código de módulo ya no se muestra en la tabla visible.

La aplicación sigue leyendo `codigoModulo` desde `ras.json` y lo mantiene dentro del JSON descargado por el usuario en cada actividad.


## Corrección adicional

- El código de módulo no se muestra en la tabla.
- El código de módulo se mantiene en el JSON descargado dentro de cada actividad.
- En vista móvil se anulan los porcentajes de anchura de columnas para que la tabla adaptada no herede el 40%.
